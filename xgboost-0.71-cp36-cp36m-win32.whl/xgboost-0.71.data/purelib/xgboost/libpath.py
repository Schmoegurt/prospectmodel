# coding: utf-8
"""Find the path to xgboost dynamic library files."""

import os
import platform
import sys


class XGBoostLibraryNotFound(Exception):
    """Error thrown by when xgboost is not found"""
    pass


def find_lib_path():
    """Find the path to xgboost dynamic library files.

    Returns
    -------
    lib_path: list(string)
       List of all found library path to xgboost
    """
    try:
        curr_path = os.path.dirname(os.path.abspath(os.path.expanduser(__file__)))
    except Exception:
        curr_path = ''
    return [os.path.join(curr_path, 'xgboost.dll')]